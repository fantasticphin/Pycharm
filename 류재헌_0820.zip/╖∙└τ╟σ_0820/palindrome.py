import sys
sys.stdin = open('palindrome.txt')

# ord = input('단어를 입력하세요: ')
#
# is_palindrome = True                 # 회문 판별값을 저장할 변수, 초깃값은 True
# for i in range(len(word) // 2):      # 0부터 문자열 길이의 절반만큼 반복
#     if word[i] != word[-1 - i]:      # 왼쪽 문자와 오른쪽 문자를 비교하여 문자가 다르면
#         is_palindrome = False        # 회문이 아님
#         break
#
# print(is_palindrome)                 # 회문 판별값 출력

# word = input('단어를 입력하세요: ')
#
# print(word == word[::-1])    # 원래 문자열과 반대로 뒤집은 문자열을 비교
#
# word = 'level'
# print(list(word) == list(reversed(word)))

T = int(input())
for tc in range(1, T + 1):
    # 입력 받기
    N, M = map(int, input().split())
    list1 = [[0]*N for i in range(N)]
    for i in range(N):
        str1 = input()
        for j in range(N):
            list1[i][j] = str1[j]
    # 회문 계산 - 가로
    for i in range(N):
        result1 = []
        flag = False # 이중 반복문 나갈려고 만들었다
        for j in range(N-M+1):  # N이 5고 M이 3일 때, 3번 반복(123,234,345)
            newList = []
            for k in range(M):
                newList.append(list1[i][j+k])  # 새로운 검사할 리스트에 더해서 새로운 리스트 만들고
            if len(newList) == M and newList == list(reversed(newList)):  # 뒤집은 것과 일치하는지. 즉 회문인지 검사
                result1 += newList
                flag = True
                break
        if(flag == True):
            break
    # 회문 계산 세로
    for i in range(N):
        flag = False
        result2 = []
        for j in range(N-M+1):
            newList = []
            for k in range(M):
                newList.append(list1[j+k][i])
            if len(newList) == M and newList == list(reversed(newList)):
                result2 += newList
                flag = True
                break
        if(flag == True):
            break

    if(result1 == []):
        result = result2
    else:
        result = result1

    print("#%s" % tc, end=" ")
    for i in range(M):
        print(result[i], end="")
    print()